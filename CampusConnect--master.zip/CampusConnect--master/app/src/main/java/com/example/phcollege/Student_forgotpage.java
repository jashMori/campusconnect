package com.example.phcollege;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

public class Student_forgotpage extends AppCompatActivity {
    AppCompatButton btn;
    EditText txt_Student_forgot_email, txt_Student_forgot_phone;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_forgotpage);
//        Find View By Id

        btn = findViewById(R.id.btn_Student_get_otp);
        txt_Student_forgot_email = findViewById(R.id.txt_teacher_forgot_email);
        txt_Student_forgot_phone = findViewById(R.id.txt_Student_forgot_phone);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Student_forgotpage.this, student_resetpassword.class));
            }
        });

    }
}