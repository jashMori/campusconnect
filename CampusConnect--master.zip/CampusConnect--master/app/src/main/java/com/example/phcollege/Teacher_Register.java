package com.example.phcollege;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

public class Teacher_Register extends AppCompatActivity {
    EditText txt_teacher_ragister_name, txt_teacher_ragister_email, txt_teacher_ragister_mobile_no, txt_teacher_ragister_pass, txt_teacher_ragister_conform_pass;
    TextView txt_teacher_ragister_Signin;

    AppCompatButton btn_teacher_ragister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_register);
// FindViewById
        txt_teacher_ragister_name = findViewById(R.id.txt_teacher_ragister_name);
        txt_teacher_ragister_email = findViewById(R.id.txt_teacher_ragister_email);
        txt_teacher_ragister_mobile_no = findViewById(R.id.txt_teacher_ragister_mobile_no);
        txt_teacher_ragister_pass = findViewById(R.id.txt_teacher_ragister_pass);
        txt_teacher_ragister_conform_pass = findViewById(R.id.txt_teacher_ragister_conform_pass);
        txt_teacher_ragister_Signin = findViewById(R.id.txt_teacher_ragister_Signin);
        btn_teacher_ragister = findViewById(R.id.btn_teacher_ragister);


//        SetOnclickListener
        txt_teacher_ragister_Signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Teacher_Register.this, Teacher_login.class));
            }
        });

        DBHelper dbHelper = new DBHelper(this);
        btn_teacher_ragister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = txt_teacher_ragister_email.getText().toString().trim();
                String password = txt_teacher_ragister_pass.getText().toString();
                String confirmPassword = txt_teacher_ragister_conform_pass.getText().toString();
                String mobile = txt_teacher_ragister_mobile_no.getText().toString().trim();
                String name = txt_teacher_ragister_name.getText().toString();

                if (name.isEmpty()) {
                    txt_teacher_ragister_name.setError("Name is required");
                    txt_teacher_ragister_name.requestFocus();
                    return;
                }

                if (email.isEmpty()) {
                    txt_teacher_ragister_email.setError("Email is required");
                    txt_teacher_ragister_email.requestFocus();
                    return;
                }

                if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    txt_teacher_ragister_email.setError("Invalid email format");
                    txt_teacher_ragister_email.requestFocus();
                    return;
                }

                if (mobile.length() != 10) {
                    txt_teacher_ragister_mobile_no.setError("Mobile number must be 10 digits");
                    txt_teacher_ragister_mobile_no.requestFocus();
                    return;
                }

                if (password.length() < 4 || password.length() > 8) {
                    txt_teacher_ragister_pass.setError("Password must be between 4 and 8 characters");
                    txt_teacher_ragister_pass.requestFocus();
                    return;
                }

                if (confirmPassword.length() < 4 || confirmPassword.length() > 8) {
                    txt_teacher_ragister_conform_pass.setError("Confirm Password is required");
                    txt_teacher_ragister_conform_pass.requestFocus();
                    return;
                }

                if (!password.equals(confirmPassword)) {
                    Toast.makeText(Teacher_Register.this, "Password and Confirm Password do not match", Toast.LENGTH_SHORT).show();
                    return;
                }

                DBHelper dbHelper = new DBHelper(Teacher_Register.this);
                Boolean checkUserEmail = dbHelper.checkEmail(email);
                if (checkUserEmail) {
                    Toast.makeText(Teacher_Register.this, "Teacher already exists! Please sign up", Toast.LENGTH_SHORT).show();
                } else {
                    Boolean insert = dbHelper.insertData(name, email, mobile, password);
                    if (insert) {
                        Toast.makeText(Teacher_Register.this, "Signup Successfully!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(Teacher_Register.this, Teacher_login.class));
                    } else {
                        Toast.makeText(Teacher_Register.this, "Signup Failed!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

    }
}