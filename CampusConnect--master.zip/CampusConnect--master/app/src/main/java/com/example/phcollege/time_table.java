package com.example.phcollege;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

public class time_table extends AppCompatActivity {
    Spinner spinner;
    ImageView imageView;
    String[] classess = {"Select Class", "________________", "FY BCA-A", "FY BCA-B", "FY BCA-C", "________________", "SY BCA-A", "SY BCA-B", "SY BCA-C", "________________", "TY BCA-A", "TY BCA-B", "TY BCA-C", "TY BCA-D"};

    //                        0                  1                2              3            4           5              6              7            8          9           10                 11           12          13
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_table);
        spinner = findViewById(R.id.time_table_spinner);
        imageView = findViewById(R.id.img_time_table);
        ArrayAdapter<CharSequence> adapter = new ArrayAdapter<>(this, R.layout.time_table_modlue, classess);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    imageView.setImageResource(R.drawable.frame);
                }
                if (position == 1) {
                    imageView.setImageResource(R.drawable.frame);
                }
                if (position == 2) {
                    imageView.setImageResource(R.drawable.fy_a);
                }
                if (position == 3) {
                    imageView.setImageResource(R.drawable.fy_b);
                }
                if (position == 4) {
                    imageView.setImageResource(R.drawable.fy_c);
                }
                if (position == 5) {
                    imageView.setImageResource(R.drawable.frame);
                }
                if (position == 6) {
                    imageView.setImageResource(R.drawable.sy_a);
                }
                if (position == 7) {
                    imageView.setImageResource(R.drawable.sy_b);
                }
                if (position == 8) {
                    imageView.setImageResource(R.drawable.sy_c);
                }
                if (position == 9) {
                    imageView.setImageResource(R.drawable.frame);
                }
                if (position == 10) {
                    imageView.setImageResource(R.drawable.ty_a);
                }
                if (position == 11) {
                    imageView.setImageResource(R.drawable.ty_b);
                }
                if (position == 12) {
                    imageView.setImageResource(R.drawable.ty_c);
                }
                if (position == 13) {
                    imageView.setImageResource(R.drawable.ty_d);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }
}