package com.example.phcollege;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Teacher_profile extends AppCompatActivity {
    String sessionname, sessionemail, sessionmobile,sessionpassword;
    TextView txtsetname, txtsetemail, txtsetmobile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_profile);
        SharedPreferences preferences = getSharedPreferences("login", MODE_PRIVATE);
//        sessionname = preferences.getString("name", "none");
        sessionemail = preferences.getString("email", "email@gmail.com");
        sessionpassword = preferences.getString("password", "password");
//        sessionmobile = preferences.getString("mobile", "9875656656");
        txtsetname = findViewById(R.id.txtsetname);
        txtsetemail = findViewById(R.id.txtsetemail);
        txtsetmobile = findViewById(R.id.txtsetphone);


        DBHelper dbHelper = new DBHelper(this);
        Cursor cursor = dbHelper.teacherProfile(sessionemail,sessionpassword);
        if(cursor.moveToFirst()) {
            sessionname = cursor.getString(0);
            sessionmobile = cursor.getString(1);

        }



        txtsetname.setText(sessionname);
        txtsetemail.setText(sessionemail);
        txtsetmobile.setText(sessionmobile);


    }
}
