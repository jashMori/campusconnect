package com.example.phcollege;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import java.util.Random;

public class Teacher_forgot_page extends AppCompatActivity {

    char[] otp;
    String mobile, email;
    EditText txt_teacher_forgot_email, txt_teacher_forgot_phone;
    AppCompatButton btn_teacher_forgot_password, btn_teacher_forgot_back;

    boolean isAllFieldsChecked = false;
    CheckAllFields checkAllFields = new CheckAllFields();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_forgot_enter_number);
//        findViewById
        btn_teacher_forgot_password = findViewById(R.id.btn_teacher_forgot_password);
        txt_teacher_forgot_phone = findViewById(R.id.txt_teacher_forgot_phone);
        txt_teacher_forgot_email = findViewById(R.id.txt_teacher_forgot_email);

//        setOnClickLister

        DBHelper dbHelper = new DBHelper(this);


        btn_teacher_forgot_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //                Check Field is Empty
                if (txt_teacher_forgot_phone.length() == 0) {
                    isAllFieldsChecked = checkAllFields.CheckFields(txt_teacher_forgot_phone);
                } else {

                    isAllFieldsChecked = checkAllFields.CheckFields(txt_teacher_forgot_email);
                }


                mobile = txt_teacher_forgot_phone.getText().toString();
                email = txt_teacher_forgot_email.getText().toString();
                boolean valid = dbHelper.checkMobileEmail(mobile, email);
                if (valid == true) {
                    Random random = new Random();
                    otp = new char[4];
                    for (int i = 0; i < 4; i++) {
                        otp[i] = (char) (random.nextInt(10) + 48);
                    }
                    Toast.makeText(Teacher_forgot_page.this, String.valueOf(otp), Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(Teacher_forgot_page.this, Teacher_forgot_change_password.class);
                    intent.putExtra("otp", String.valueOf(otp));
                    intent.putExtra("email", email);
                    startActivity(intent);
                } else {
                    Toast.makeText(Teacher_forgot_page.this, "User invalid!!", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

}

