package com.example.phcollege;

import android.app.Dialog;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class Add_Student extends AppCompatActivity {
    RecyclerView recyclerView;
    ArrayList<StudentModel> arrStudent = new ArrayList<>();
    FloatingActionButton addbtn;
    RecyclerStudentAdapter adapter;
    EditText edtname, edtemail, edtphone, edtadd, edtpass;
    AppCompatButton btn_add_update;
    String name, email, phone, add, pass;
    String rollno;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_student);


        StudentDBHelper studentDBHelper = new StudentDBHelper(this);


//        findViewById
        recyclerView = findViewById(R.id.recycler_add_student);
        addbtn = findViewById(R.id.btnOpenDialog);
//        setLayoutManger
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
//        SetOncilcklisterner
        addbtn.setOnClickListener(v -> {
            Dialog dialog = new Dialog(Add_Student.this);
            dialog.setContentView(R.layout.add_update_layout);

            edtname = dialog.findViewById(R.id.txt_update_name);
            edtemail = dialog.findViewById(R.id.txt_update_email);
            edtphone = dialog.findViewById(R.id.txt_update_phone);
            edtadd = dialog.findViewById(R.id.txt_update_address);
            edtpass = dialog.findViewById(R.id.txt_update_pass);
            btn_add_update = dialog.findViewById(R.id.btn_add_update);

            btn_add_update.setOnClickListener(v1 -> {
                rollno="";
                name = "";
                email = "";
                phone = "";
                add = "";
                pass = "";
                fieldCcheck();
                if (!edtname.getText().toString().equals("") && !edtemail.getText().toString().equals("") && !edtphone.getText().toString().equals("") && !edtadd.getText().toString().equals("") && !edtpass.getText().toString().equals("")) {
                    arrStudent.add(new StudentModel(rollno,name, email, phone, add, pass));
                    adapter.notifyItemInserted(arrStudent.size() - 1);
                    recyclerView.scrollToPosition(arrStudent.size() - 1);

//                            Add Student database


                    Boolean addStud = studentDBHelper.addStudent(name, email, phone, add, pass);

                    if (addStud) {
                        Toast.makeText(Add_Student.this, "Record inserted", Toast.LENGTH_LONG).show();
                    }
                    dialog.dismiss();

                } else {
                    Toast.makeText(Add_Student.this, "Not add record", Toast.LENGTH_SHORT).show();
                }
            });
            dialog.show();
        });

//Select Query
//        Database View

        Cursor cursor = studentDBHelper.allStudent();
//        show the student details.

        while (cursor.moveToNext()) {
            arrStudent.add(new StudentModel(cursor.getString(0), cursor.getString(1), cursor.getString(2),
                    cursor.getString(3), cursor.getString(4),cursor.getString(5)));
        }

        adapter = new RecyclerStudentAdapter(this, arrStudent);
        recyclerView.setAdapter(adapter);

    }

    private void fieldCcheck() {

        if (!edtname.getText().toString().equals("")) {
            name = edtname.getText().toString();
        } else {
            Toast.makeText(this, "This field is required", Toast.LENGTH_SHORT).show();
        }

        if (!edtemail.getText().toString().equals("")) {

            email = edtemail.getText().toString();
        } else {
            Toast.makeText(this, "This field is required", Toast.LENGTH_SHORT).show();
        }


        if (!edtphone.getText().toString().equals("")) {
            phone = edtphone.getText().toString();
        } else {
            Toast.makeText(this, "This field is required", Toast.LENGTH_SHORT).show();
        }

        if (!edtadd.getText().toString().equals("")) {
            add = edtadd.getText().toString();
        } else {
            Toast.makeText(this, "This field is required", Toast.LENGTH_SHORT).show();
        }

        if (!edtpass.getText().toString().equals("")) {
            pass = edtpass.getText().toString();
        } else {
            Toast.makeText(this, "This field is required", Toast.LENGTH_SHORT).show();
        }

    }
}