package com.example.phcollege;

import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class CheckAllFields extends AppCompatActivity {
    boolean CheckFields(EditText editText) {


        if (editText.length() == 0) {
            editText.setError("This field is required");
            return false;
        }

        // after all validation return true.
        return true;
    }

}
