package com.example.phcollege;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

public class Student_login extends AppCompatActivity {

    EditText stdusername, stdpassword;
    TextView stdforgot;
    AppCompatButton stdlogin;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_student_login);

        stdusername = findViewById(R.id.student_usernm);
        stdpassword = findViewById(R.id.student_pass);
        stdforgot = findViewById(R.id.txt_student_login_forgot_pass);
        stdlogin = findViewById(R.id.studentloginbtn);

        StudentDBHelper studentDBHelper = new StudentDBHelper(this);

        stdlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = stdusername.getText().toString().trim();
                String password = stdpassword.getText().toString().trim();

                if (email.isEmpty() || password.isEmpty()) {
                    Toast.makeText(Student_login.this, "All fields are mandatory", Toast.LENGTH_SHORT).show();
                } else if (!isValidEmail(email)) {
                    Toast.makeText(Student_login.this, "Invalid email format", Toast.LENGTH_SHORT).show();
                } else {
                    Boolean checkStudent = studentDBHelper.checkEmailPassword(email, password);
                    if (checkStudent) {
                        Toast.makeText(Student_login.this, "Login Successfully!", Toast.LENGTH_SHORT).show();
                        Shared();

                        Intent intent_forgot2 = new Intent(Student_login.this, Student_daseboard.class);
                        startActivity(intent_forgot2);
                    } else {
                        Toast.makeText(Student_login.this, "Invalid email or password", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        stdforgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent_forgot2 = new Intent(Student_login.this, Student_forgotpage.class);
                startActivity(intent_forgot2);
            }
        });
    }

    void Shared() {
        SharedPreferences preferences = getSharedPreferences("studlogin", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        stdusername = findViewById(R.id.student_usernm);
        String studentEmail = stdusername.getText().toString().trim();
        stdpassword = findViewById(R.id.student_pass);
        String studentPassword = stdpassword.getText().toString().trim();
        editor.putString("email", studentEmail);
        editor.putString("password", studentPassword);
        editor.apply();
    }

    // Email format validation function
    private boolean isValidEmail(CharSequence target) {
        return !TextUtils.isEmpty(target) && android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }
}

