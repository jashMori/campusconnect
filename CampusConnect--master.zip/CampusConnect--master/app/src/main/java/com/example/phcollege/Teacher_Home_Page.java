package com.example.phcollege;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class Teacher_Home_Page extends AppCompatActivity {
    TextView txtwellcome;
    String sessionname, sessionemail,sessionpassword;

    CardView cardView_add_student, card_view_add_material, card_view_holiday, card_view_time_table, card_view_profile, card_view_logout;

    @SuppressLint({"MissingInflatedId", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_home_page);
//        FindViewById
        txtwellcome = findViewById(R.id.txtwellcometecher);
        cardView_add_student = findViewById(R.id.card_view_add_student);
        card_view_add_material = findViewById(R.id.card_view_add_material);
        card_view_holiday = findViewById(R.id.card_view_holiday);
        card_view_time_table = findViewById(R.id.card_view_time_table);
        card_view_profile = findViewById(R.id.card_view_profile);
        card_view_logout = findViewById(R.id.card_view_logout);

sessionname();
txtwellcome.setText("Welcome "+sessionname);
//    ClickListener


        cardView_add_student.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Teacher_Home_Page.this, Add_Student.class));
                Toast.makeText(Teacher_Home_Page.this, "Click_student", Toast.LENGTH_SHORT).show();
            }
        });
        card_view_add_material.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Teacher_Home_Page.this, download_pdf.class));

            }
        });
        card_view_holiday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Teacher_Home_Page.this, Holiday.class));
                Toast.makeText(Teacher_Home_Page.this, "Click_holiday", Toast.LENGTH_SHORT).show();

            }
        });
        card_view_time_table.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Teacher_Home_Page.this, time_table.class));

            }
        });
        card_view_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Teacher_Home_Page.this, Teacher_profile.class));
                Toast.makeText(Teacher_Home_Page.this, "Click_Profile", Toast.LENGTH_SHORT).show();

            }
        });
        card_view_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                startActivity(new Intent(Teacher_Home_Page.this, Teacher_login.class));

                AlertDialog.Builder builder = new AlertDialog.Builder(Teacher_Home_Page.this);
                builder.setMessage("Do you want to Logout ?");
                builder.setTitle("Alert !");
                builder.setCancelable(false);
                builder.setPositiveButton("Yes", (DialogInterface.OnClickListener) (dialog, which) -> {
                    finish();
                    Sharad();
                });
                builder.setNegativeButton("No", (DialogInterface.OnClickListener) (dialog, which) -> {
                    dialog.cancel();
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        });
    }

    private void sessionname() {
        SharedPreferences preferences = getSharedPreferences("login", MODE_PRIVATE);
        sessionemail = preferences.getString("email", "email@gmail.com");
        sessionpassword = preferences.getString("password", "password");
        DBHelper dbHelper = new DBHelper(this);
        Cursor cursor = dbHelper.teacherProfile(sessionemail,sessionpassword);
        if(cursor.moveToFirst()) {
            sessionname = cursor.getString(0);
        }

    }

    void Sharad() {
        SharedPreferences preferences = getSharedPreferences("login", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("flag", false);
        editor.apply();
    }
}