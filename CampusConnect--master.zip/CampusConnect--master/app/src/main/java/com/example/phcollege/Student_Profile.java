package com.example.phcollege;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Student_Profile extends AppCompatActivity {
    String sessionname, sessionemail, sessionmobile, sessionaddress,sessionpassword;
    TextView txtsetname, txtsetemail, txtsetmobile, txtsetadddress;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_profile);
        SharedPreferences preferences = getSharedPreferences("studlogin", MODE_PRIVATE);

        sessionemail = preferences.getString("email", "email@gmail.com");

        sessionpassword = preferences.getString("password", "password");
        txtsetname = findViewById(R.id.txtstudsetname);
        txtsetemail = findViewById(R.id.txtstudsetemail);
        txtsetmobile = findViewById(R.id.txtstudsetphone);
        txtsetadddress = findViewById(R.id.txtstudsetaddress);

        StudentDBHelper studentDBHelper = new StudentDBHelper(this);
        Cursor cursor = studentDBHelper.studentProfile(sessionemail,sessionpassword);
        if(cursor.moveToFirst()) {
            sessionname = cursor.getString(0);
            sessionmobile = cursor.getString(1);
            sessionaddress = cursor.getString(2);
        }


        txtsetname.setText(sessionname.toString());
        txtsetemail.setText(sessionemail.toString());
        txtsetmobile.setText(sessionmobile.toString());
        txtsetadddress.setText(sessionaddress.toString());
    }
}