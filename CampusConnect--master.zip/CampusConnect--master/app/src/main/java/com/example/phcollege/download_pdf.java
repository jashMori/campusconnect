package com.example.phcollege;

import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;

public class download_pdf extends AppCompatActivity {
    Button btn;
    ListView listView;
    String[] Name, Link;
    Integer[] imgid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_download_pdf);
        listView = findViewById(R.id.list_view_pdf);
        Name = new String[]{
                "Android Notes",
                "Bash Notes",
                " C Notes",
                ".NET Framework Notes",
                " Java Notes",
                "JavaScript Notes",
                "Kotlin Notes",
                "Node.JS Notes",
                "PHP Notes",
        };
        Link = new String[]{
//             1
                "https://drive.google.com/uc?id=1VihLICRRu3-Bg-wpgXjeUrA0nAwsvgFC&export=download",
//                2
                "https://drive.google.com/uc?id=1EvgMdbPgh_nl8OvHgw0fKbTWqynjejgE&export=download",
//                3
                "https://drive.google.com/uc?id=1k1R2oxyTNe1k4EoY-58noHLme6cNDnlD&export=download",
//                4
                "https://drive.google.com/uc?id=1g2Fbv2Ldj7xaPX8HQfazi0cSlEupHAOe&export=download",
//                5
                "https://drive.google.com/uc?id=1NyVsk9C17Lw70raD8swz4XJEhEbGwmTN&export=download",
//                6
                "https://drive.google.com/uc?id=1D-vQ2OJTMWR9ZJwW1tBv4JI6rbUsCg9Q&export=download",
//                7
                "https://drive.google.com/uc?id=1YPqFONF2BRxjpJFnNc1C4RK8TohYX6_B&export=download",
//                8
                "https://drive.google.com/uc?id=1d1uRfRiK90FKXNgtz8EMV5pJsPYFJIx6&export=download",
//                9
                "https://drive.google.com/uc?id=1TgGz7wOYdXuALTLMQ73e6Uj9X8dCrnbC&export=download",
        };
        Integer[] imgid = new Integer[]{
                R.drawable.androidgrow,
                R.drawable.bash,
                R.drawable.cgrow,
                R.drawable.dotnet,
                R.drawable.javagrow,
                R.drawable.js,
                R.drawable.kotlin,
                R.drawable.nodsjs,
                R.drawable.php,

        };

        MyListAdepter adepter = new MyListAdepter(this, Name, imgid);
        listView.setAdapter(adepter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                initDownload(Link[position], position);
            }
        });
    }


    private void initDownload(String uri, int postion) {
        download(getApplicationContext(), Name[postion], ".pdf", "Downloads", uri.trim());
    }

    private void download(Context context, String Filename, String FileExtension, String DesignationDirectory, String url) {
        DownloadManager downloadManager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
        Uri uri = Uri.parse(url);
        DownloadManager.Request request = new DownloadManager.Request(uri);
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        request.setDestinationInExternalFilesDir(context, DesignationDirectory, Filename + FileExtension);
        assert downloadManager != null;
        downloadManager.enqueue(request);
        Snackbar snackbar = (Snackbar) Snackbar.make(findViewById(android.R.id.content), "Downloading...", Snackbar.LENGTH_LONG);
        snackbar.show();
    }
}