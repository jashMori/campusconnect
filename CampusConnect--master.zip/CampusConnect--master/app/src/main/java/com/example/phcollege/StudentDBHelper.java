package com.example.phcollege;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class StudentDBHelper extends SQLiteOpenHelper {
    public static final String DBName = "Studentdb";
    public static final String TABLE_NAME_STUDENT = "student";

    public StudentDBHelper(Context context) {
        super(context, DBName, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase MyDB) {
        MyDB.execSQL("create table student(rollno INTEGER primary key autoincrement,name text not null,email email unique," +
                "mobileno text not null,address text not null,password password not null)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1) {
        MyDB.execSQL("drop Table if exists student");
        onCreate(MyDB);
    }

    public Boolean addStudent(String name, String email, String mobileno, String address, String password) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("email", email);
        contentValues.put("mobileno", mobileno);
        contentValues.put("address", address);
        contentValues.put("password", password);
        long result = MyDB.insert("student", null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public Cursor allStudent() {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("select rollno,name,email,mobileno,address,password from student", null);
        return cursor;
    }


    public Boolean checkEmailPassword(String email, String password) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select email,password from student where email = ? and password = ?", new String[]{email, password});
        if (cursor.getCount() > 0) {
            return true;
        } else {
            return false;
        }
    }


    public void allDetailsUpdate(String roll, String name, String email, String mobileno, String address, String password) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        int rollno = Integer.parseInt(roll);
        contentValues.put("rollno", rollno);
        contentValues.put("name", name);
        contentValues.put("email", email);
        contentValues.put("mobileno", mobileno);
        contentValues.put("address", address);
        contentValues.put("password", password);
        MyDB.update(TABLE_NAME_STUDENT, contentValues, "rollno=?", new String[]{roll});
    }


    public void deleteStudent(String rollno) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        MyDB.delete(TABLE_NAME_STUDENT, "rollno=?", new String[]{rollno});
    }

    public Cursor studentProfile(String email, String password) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select name,mobileno,address from student where email = ? and password = ?", new String[]{email, password});
        return cursor;
    }
}
