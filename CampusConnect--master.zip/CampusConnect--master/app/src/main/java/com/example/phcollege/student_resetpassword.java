package com.example.phcollege;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

public class student_resetpassword extends AppCompatActivity {
    EditText student_newpassword, student_confirmpassword;
    AppCompatButton studentresetbtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_resetpassword);
        student_newpassword = findViewById(R.id.student_newpassword);
        student_confirmpassword = findViewById(R.id.student_confirmpassword);
        studentresetbtn = findViewById(R.id.studentresetbtn);
        studentresetbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(student_resetpassword.this, Student_login.class));
                Toast.makeText(student_resetpassword.this, "Reset button clicked", Toast.LENGTH_SHORT).show();
            }
        });

    }
}