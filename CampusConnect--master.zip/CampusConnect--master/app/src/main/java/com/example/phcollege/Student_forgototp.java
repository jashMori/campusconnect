package com.example.phcollege;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Student_forgototp extends AppCompatActivity {

    EditText txt_student_forgot_page_opt_1,
            txt_student_forgot_page_opt_2,
            txt_student_forgot_page_opt_3,
            txt_student_forgot_page_opt_4;

    AppCompatButton student_otpvarification_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_forgototp);
        txt_student_forgot_page_opt_1 = findViewById(R.id.txt_student_forgot_opt_1);
        txt_student_forgot_page_opt_2 = findViewById(R.id.txt_student_forgot_opt_2);
        txt_student_forgot_page_opt_3 = findViewById(R.id.txt_student_forgot_opt_3);
        txt_student_forgot_page_opt_4 = findViewById(R.id.txt_student_forgot_opt_4);

        student_otpvarification_btn = findViewById(R.id.student_otpverification_button);

        student_otpvarification_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Student_forgototp.this , student_resetpassword.class);
                startActivity(intent);

            }
        });


    }
}