package com.example.phcollege;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class selection_page extends AppCompatActivity {
    ImageView view_student, view_teacher;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection_page);
//        FindViewById
        view_student = findViewById(R.id.student);
        view_teacher = findViewById(R.id.teacher);
//    onClickListener
        view_student.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Intent to connect student page
                Intent intent1  = new Intent(selection_page.this,Student_login.class);
                startActivity(intent1);

            }
        });
        view_teacher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Intent to connect teacher page
                SharedPreferences preferences = getSharedPreferences("login",MODE_PRIVATE);
                boolean check = preferences.getBoolean("flag",false);
                if (check){
                    startActivity(new Intent(selection_page.this, Teacher_Home_Page.class));
                }
                else {

                startActivity(new Intent(selection_page.this, Teacher_login.class));
                }
            }
        });
    }
}