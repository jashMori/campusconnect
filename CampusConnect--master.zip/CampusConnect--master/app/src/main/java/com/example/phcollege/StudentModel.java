package com.example.phcollege;

public class StudentModel {
    String name, email, mobileno, address, password;
    String roll;

    public StudentModel(String roll, String name, String email, String mobileno, String address, String password) {
        this.roll = roll;
        this.name = name;
        this.email = email;
        this.mobileno = mobileno;
        this.address = address;
        this.password = password;
    }
}
