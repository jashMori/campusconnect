package com.example.phcollege;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

//public class Teacher_forgot_change_password extends AppCompatActivity {
//    EditText txt_teacher_Change_pass, txt_teacher_Change_conform_pass;
//    AppCompatButton btn_teacher_forgot_Reset_Pass;
//    String email;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_teacher_forgot_change_password);
////        FindViewById
//        txt_teacher_Change_conform_pass = findViewById(R.id.txt_teacher_Change_conform_pass);
//        txt_teacher_Change_pass = findViewById(R.id.txt_teacher_Change_pass);
//        btn_teacher_forgot_Reset_Pass = findViewById(R.id.btn_teacher_forgot_Reset_Pass);
//
//        Intent intent = getIntent();
//        email = intent.getStringExtra("email");
//
//        DBHelper dbHelper = new DBHelper(this);
//
//        btn_teacher_forgot_Reset_Pass.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                String password = txt_teacher_Change_pass.getText().toString();
//                String conformPassword = txt_teacher_Change_conform_pass.getText().toString();
//
////                Toast.makeText(Teacher_forgot_change_password.this,"Password = "+ password + " Cnpass = "+ conformPassword,Toast.LENGTH_LONG).show();
//
//                if (password.equals(conformPassword)) {
//
//                    dbHelper.forgetTeacherPassword(password,email);
//
//                    Toast.makeText(Teacher_forgot_change_password.this,"Password update successfully!.",Toast.LENGTH_LONG).show();
//                    startActivity(new Intent(Teacher_forgot_change_password.this, Teacher_login.class));
//
//                } else {
//                    Toast.makeText(Teacher_forgot_change_password.this,"Please enter Password and Conform Password must be same.",Toast.LENGTH_LONG).show();
//                }
//
//
//            }
//        });
//    }
//}
// ... (previous imports and package declaration)

public class Teacher_forgot_change_password extends AppCompatActivity {
    EditText txt_teacher_Change_pass, txt_teacher_Change_conform_pass;
    AppCompatButton btn_teacher_forgot_Reset_Pass;
    String email;

    // Set maximum password length
    private static final int MAX_PASSWORD_LENGTH = 8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_forgot_change_password);
        // FindViewById
        txt_teacher_Change_conform_pass = findViewById(R.id.txt_teacher_Change_conform_pass);
        txt_teacher_Change_pass = findViewById(R.id.txt_teacher_Change_pass);
        btn_teacher_forgot_Reset_Pass = findViewById(R.id.btn_teacher_forgot_Reset_Pass);

        Intent intent = getIntent();
        email = intent.getStringExtra("email");

        DBHelper dbHelper = new DBHelper(this);

        btn_teacher_forgot_Reset_Pass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String password = txt_teacher_Change_pass.getText().toString();
                String conformPassword = txt_teacher_Change_conform_pass.getText().toString();

                // Validate password and conformPassword
                if (password.isEmpty() || conformPassword.isEmpty()) {
                    Toast.makeText(Teacher_forgot_change_password.this, "Please enter both Password and Conform Password.", Toast.LENGTH_LONG).show();
                } else if (password.length() < 4||password.length() > MAX_PASSWORD_LENGTH) {
                    Toast.makeText(Teacher_forgot_change_password.this, "Password must be between 4 and "+ MAX_PASSWORD_LENGTH +" characters.", Toast.LENGTH_LONG).show();
                } else if (!password.equals(conformPassword)) {
                    Toast.makeText(Teacher_forgot_change_password.this, "Password and Conform Password must match.", Toast.LENGTH_LONG).show();
                } else {
                    dbHelper.forgetTeacherPassword(password, email);
                    Toast.makeText(Teacher_forgot_change_password.this, "Password updated successfully!", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(Teacher_forgot_change_password.this, Teacher_login.class));
                }
            }
        });
    }
}
