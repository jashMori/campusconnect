package com.example.phcollege;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DBName = "Teacherdb";

    public static final String TABLE_NAME_TEACHER = "teacher";

//    public static final String TABLE_NAME_STUDENT = "student";

    public DBHelper(Context context) {
        super(context, DBName, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase MyDB) {
        MyDB.execSQL("create table teacher(name text not null,email email primary key,mobile number(10) not null,password password not null)");
//        MyDB.execSQL("create table student(rollno number primary key autoincrement,name text not null,email email unique," +
//                "mobile number(10) not null,address text not null,password password not null,adharno number(12))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int oldVersion, int newVersion) {
        MyDB.execSQL("drop Table if exists teacher");
//        MyDB.execSQL("drop Table if exists student");
        onCreate(MyDB);
    }

    public Boolean insertData(String name1, String email1, String mobile1, String password1) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name1);
        contentValues.put("email", email1);
        contentValues.put("mobile", mobile1);
        contentValues.put("password", password1);
        long result = MyDB.insert("teacher", null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }


    public Boolean checkEmail(String email) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select email from teacher where email = ?", new String[]{email});
        if (cursor.getCount() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public Boolean checkEmailPassword(String email, String password) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select email,password from teacher where email = ? and password = ?", new String[]{email, password});
        if (cursor.getCount() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public Boolean checkMobilePassword(String mobile, String password) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select mobile,password from teacher where mobile = ? and password = ?", new String[]{mobile, password});
        if (cursor.getCount() > 0) {
            return true;
        } else {
            return false;
        }
    }


//    String teacherEmail;

    public Boolean checkMobileEmail(String mobile, String email) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select mobile,email from teacher where mobile = ? and email = ?", new String[]{mobile, email});
        if (cursor.getCount() > 0) {
//            teacherEmail = email;
            return true;
        } else {
            return false;
        }
    }

    public void forgetTeacherPassword(String password, String email) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("password", password);
        contentValues.put("email", email);
        MyDB.update(TABLE_NAME_TEACHER, contentValues, "email=?", new String[]{email});

    }

    public Cursor teacherProfile(String email, String password) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select name,mobile from teacher where email = ? and password = ?", new String[]{email, password});
        return cursor;
    }

}
