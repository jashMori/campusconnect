package com.example.phcollege;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

public class Teacher_forgot_page_otp extends AppCompatActivity {
    EditText txt_teacher_forgot_page_opt_1,
            txt_teacher_forgot_page_opt_2,
            txt_teacher_forgot_page_opt_3,
            txt_teacher_forgot_page_opt_4;
    AppCompatButton btn_teacher_forgot_page_otp_verification;
    String otp;
    String email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_forgot_page_otp);
        txt_teacher_forgot_page_opt_1 = findViewById(R.id.txt_teacher_forgot_page_opt_1);
        txt_teacher_forgot_page_opt_2 = findViewById(R.id.txt_teacher_forgot_page_opt_2);
        txt_teacher_forgot_page_opt_3 = findViewById(R.id.txt_teacher_forgot_page_opt_3);
        txt_teacher_forgot_page_opt_4 = findViewById(R.id.txt_teacher_forgot_page_opt_4);
        btn_teacher_forgot_page_otp_verification = findViewById(R.id.btn_teacher_forgot_page_otp_verification);

        Intent intent = getIntent();
        otp = intent.getStringExtra("otp");
        email = intent.getStringExtra("email");
        btn_teacher_forgot_page_otp_verification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String otp0 = txt_teacher_forgot_page_opt_1.getText().toString();
                String otp1 = txt_teacher_forgot_page_opt_2.getText().toString();
                String otp2 = txt_teacher_forgot_page_opt_3.getText().toString();
                String otp3 = txt_teacher_forgot_page_opt_4.getText().toString();

                String o0 = String.valueOf(otp.charAt(0));
                String o1 = String.valueOf(otp.charAt(1));
                String o2 = String.valueOf(otp.charAt(2));
                String o3 = String.valueOf(otp.charAt(3));

//                Toast.makeText(Teacher_forgot_page_otp.this,String.valueOf(otp0.equals(o0)), Toast.LENGTH_LONG).show();
                if(otp0.equals(o0) && otp1.equals(o1) && otp2.equals(o2) && otp3.equals(o3)) {
                    Toast.makeText(Teacher_forgot_page_otp.this, "Wow OTP is correct!!", Toast.LENGTH_LONG).show();
                    Intent intent1 = new Intent(Teacher_forgot_page_otp.this,Teacher_forgot_change_password.class);
                    intent1.putExtra("email",email);
                    startActivity(intent1);
//                    startActivity(new Intent(Teacher_forgot_page_otp.this,Teacher_forgot_change_password.class));
                } else {
                    Toast.makeText(Teacher_forgot_page_otp.this,"Invalid OTP!!",Toast.LENGTH_LONG).show();
                }
            }
        });
        numberChange();

    }

    private void numberChange() {
        txt_teacher_forgot_page_opt_1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int Start, int Count, int End) {

            }

            @Override
            public void onTextChanged(CharSequence s, int Start, int Count, int End) {
                if (!s.toString().trim().isEmpty()) {
                    txt_teacher_forgot_page_opt_2.requestFocus();
                }

            }


            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        txt_teacher_forgot_page_opt_2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int Start, int Count, int End) {

            }

            @Override
            public void onTextChanged(CharSequence s, int Start, int Count, int End) {
                if (!s.toString().trim().isEmpty()) {
                    txt_teacher_forgot_page_opt_3.requestFocus();
                }

            }


            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().isEmpty()) {
                    txt_teacher_forgot_page_opt_1.requestFocus();
                }
            }
        });
        txt_teacher_forgot_page_opt_3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int Start, int Count, int End) {

            }

            @Override
            public void onTextChanged(CharSequence s, int Start, int Count, int End) {
                if (!s.toString().trim().isEmpty()) {
                    txt_teacher_forgot_page_opt_4.requestFocus();
                }

            }


            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().isEmpty()) {
                    txt_teacher_forgot_page_opt_2.requestFocus();
                }
            }
        });
//

        txt_teacher_forgot_page_opt_4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int Start, int Count, int End) {

            }

            @Override
            public void onTextChanged(CharSequence s, int Start, int Count, int End) {

            }


            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().isEmpty()) {
                    txt_teacher_forgot_page_opt_3.requestFocus();
                }
            }
        });
    }
}
