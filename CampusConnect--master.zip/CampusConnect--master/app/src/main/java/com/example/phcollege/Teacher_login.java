package com.example.phcollege;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

public class Teacher_login extends AppCompatActivity {
    EditText edt_teacher_id, edt_teacher_password;
    TextView txt_teacher_login_forgot, txt_teacher_login_SignUp;
    AppCompatButton btn_teacher_login;
    boolean isAllFieldsChecked = false;
    CheckAllFields checkAllFields = new CheckAllFields();

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_login);
//    findViewById
        edt_teacher_id = findViewById(R.id.teacher_login_id);
        edt_teacher_password = findViewById(R.id.teacher_login_pass);
        btn_teacher_login = findViewById(R.id.teacher_login_button);
        txt_teacher_login_forgot = findViewById(R.id.txt_teacher_login_forgot_pass);
        txt_teacher_login_SignUp = findViewById(R.id.txt_teacher_login_Signup);

//    SetOnclickListener
//        btn_teacher_login.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Toast.makeText(Teacher_login.this, "ID :- " + edt_teacher_id.getText().toString() + "\nPassword :- " + edt_teacher_password.getText().toString(), Toast.LENGTH_SHORT).show();
//            }
//        });
        txt_teacher_login_forgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Teacher_login.this, Teacher_forgot_page.class));
            }
        });
        txt_teacher_login_SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Teacher_login.this, Teacher_Register.class));
            }
        });

        DBHelper dbHelper = new DBHelper(this);

        btn_teacher_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = edt_teacher_id.getText().toString();
                String password = edt_teacher_password.getText().toString();
                String mobile = edt_teacher_id.getText().toString();

// Check null is field

                isAllFieldsChecked = checkAllFields.CheckFields(edt_teacher_id);


//                Toast.makeText(Teacher_login.this, "ID :- " + edt_teacher_id.getText().toString() + "\nPassword :- " + edt_teacher_password.getText().toString(), Toast.LENGTH_SHORT).show();
//                Toast.makeText(Teacher_login.this, "ID :- " + email + "\nPassword :- " + password, Toast.LENGTH_SHORT).show();
                if (email.equals("") || password.equals("")) {
                    Toast.makeText(Teacher_login.this, "All fields are mandatory", Toast.LENGTH_SHORT).show();
                } else {
                    Boolean checkTeacher = dbHelper.checkEmailPassword(email, password);
                    Boolean checkMobileTeacher = dbHelper.checkMobilePassword(mobile, password);
                    if (checkTeacher == true || checkMobileTeacher == true) {
                        startActivity(new Intent(Teacher_login.this, Teacher_Home_Page.class));

//                       Shared Preferences Use
                        Shared();

                        Toast.makeText(Teacher_login.this, "Login Successfully!", Toast.LENGTH_SHORT).show();

//                        Here Intent passing code

                    } else {
                        Toast.makeText(Teacher_login.this, "Invalid email or password", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    //SharedPreferences
    void Shared() {
        SharedPreferences preferences = getSharedPreferences("login", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("flag", true);

        edt_teacher_id = findViewById(R.id.teacher_login_id);
        edt_teacher_password = findViewById(R.id.teacher_login_pass);
        String sessionEmail = edt_teacher_id.getText().toString();
        String sessionPassword = edt_teacher_password.getText().toString();

        editor.putString("email",sessionEmail);
        editor.putString("password",sessionPassword);

        editor.apply();
    }
}