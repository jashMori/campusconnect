package com.example.phcollege;

import android.os.AsyncTask;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class FetchHolidaysTask extends AsyncTask<String, Void, String> {

    private OnFetchCompleteListener listener;
    private String result;

    public interface OnFetchCompleteListener {
        void onFetchComplete(String result);
    }

    public void setOnFetchCompleteListener(OnFetchCompleteListener listener) {
        this.listener = listener;
    }

    @Override
    protected String doInBackground(String... urls) {
        StringBuilder result = new StringBuilder();

        try {
            URL url = new URL(urls[0]);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;

            while ((line = reader.readLine()) != null) {
                result.append(line);
            }

            reader.close();
            connection.disconnect();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return result.toString();
    }

    @Override
    protected void onPostExecute(String result) {
        this.result = result;
        if (listener != null) {
            listener.onFetchComplete(result);
        }
    }
}
