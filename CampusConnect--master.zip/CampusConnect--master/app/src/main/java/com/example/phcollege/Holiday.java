package com.example.phcollege;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Holiday extends AppCompatActivity {
    private ListView holidayListView;
    private List<String> holidayNamesList;
    private static final String API_KEY = "JXkpf5FjUqEKd499DcysCKpPL4WDM0FT"; // Update with your new API key
    private static final String API_BASE_URL = "https://calendarific.com/api/v2/holidays";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_holiday);
        holidayListView = findViewById(R.id.holidayListView1);
        holidayNamesList = new ArrayList<>();

        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        String apiUrl = API_BASE_URL + "?api_key=" + API_KEY + "&country=IN&year=" + currentYear;

        FetchHolidaysTask fetchHolidaysTask = new FetchHolidaysTask();
        fetchHolidaysTask.setOnFetchCompleteListener(new FetchHolidaysTask.OnFetchCompleteListener() {
            @Override
            public void onFetchComplete(String result) {
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    JSONArray holidaysArray = jsonObject.getJSONObject("response").getJSONArray("holidays");

                    for (int i = 0; i < holidaysArray.length(); i++) {
                        JSONObject holidayObject = holidaysArray.getJSONObject(i);
                        String holidayName = holidayObject.getString("name");
                        String holidayDate = holidayObject.getJSONObject("date").getString("iso");
                        String holidayDescription = holidayObject.getString("description");

                        String holidayInfo = "Name: " + holidayName + "\nDate: " + holidayDate + "\nDescription: " + holidayDescription;

                        holidayNamesList.add(holidayInfo);
                    }

                    ArrayAdapter adapter = new ArrayAdapter<>(Holiday.this, R.layout.list_item, R.id.holidayNameTextView, holidayNamesList);
                    holidayListView.setAdapter(adapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });

        fetchHolidaysTask.execute(apiUrl);
    }
}