package com.example.phcollege;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class Student_daseboard extends AppCompatActivity {
    CardView card_view_student_add_material, card_view_student_holiday, card_view_student_time_table, card_view_student_profile, card_view_student_logout;
    TextView txtwellcome;
    String sessionname, sessionemail,sessionpassword;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_daseboard);
        card_view_student_add_material = findViewById(R.id.card_view_student_add_material);
        card_view_student_holiday = findViewById(R.id.card_view_student_holiday);
        card_view_student_time_table = findViewById(R.id.card_view_student_time_table);
        card_view_student_profile = findViewById(R.id.card_view_student_profile);
        card_view_student_logout = findViewById(R.id.card_view_student_logout);
        txtwellcome = findViewById(R.id.txtwellcomestudent);
        sessionname();
        txtwellcome.setText("Welcome "+sessionname);
        card_view_student_add_material.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Student_daseboard.this, download_pdf.class));
            }
        });
        card_view_student_holiday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Student_daseboard.this, Holiday.class));
            }
        });
        card_view_student_time_table.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Student_daseboard.this, time_table.class));
            }
        });
        card_view_student_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Student_daseboard.this, Student_Profile.class));
            }
        });
        card_view_student_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Student_daseboard.this);
                builder.setMessage("Do you want to Logout ?");
                builder.setTitle("Alert !");
                builder.setCancelable(false);
                builder.setPositiveButton("Yes", (DialogInterface.OnClickListener) (dialog, which) -> {
                    finish();
                });
                builder.setNegativeButton("No", (DialogInterface.OnClickListener) (dialog, which) -> {
                    dialog.cancel();
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        });

    }

    private void sessionname() {
        SharedPreferences preferences = getSharedPreferences("studlogin", MODE_PRIVATE);
        sessionemail = preferences.getString("email", "email@gmail.com");
        sessionpassword = preferences.getString("password", "password");
        StudentDBHelper studentDBHelper = new StudentDBHelper(this);
        Cursor cursor = studentDBHelper.studentProfile(sessionemail,sessionpassword);
        if(cursor.moveToFirst()) {
            sessionname = cursor.getString(0);
        }
    }
}