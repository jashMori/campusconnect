package com.example.phcollege;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerStudentAdapter extends RecyclerView.Adapter<RecyclerStudentAdapter.viewHolder> {
    Context context;
    ArrayList<StudentModel> arrstudent;


    RecyclerStudentAdapter(Context context, ArrayList<StudentModel> arrstudent) {
        this.context = context;
        this.arrstudent = arrstudent;
    }

    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.add_student_view, parent, false);
        viewHolder viewholder = new viewHolder(view);
        return viewholder;
    }

    @Override
    public void onBindViewHolder(@NonNull viewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.txtroll.setText(arrstudent.get(position).roll);
        holder.txtname.setText(arrstudent.get(position).name);
        holder.txtemail.setText(arrstudent.get(position).email);
        holder.txtmobile.setText(arrstudent.get(position).mobileno);
        holder.txtaddress.setText(arrstudent.get(position).address);
        holder.txtpassword.setText(arrstudent.get(position).password);


        holder.layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dialog dialog = new Dialog(context);
                dialog.setContentView(R.layout.add_update_layout);
                EditText edtname = dialog.findViewById(R.id.txt_update_name);
                EditText edtemail = dialog.findViewById(R.id.txt_update_email);
                EditText edtphone = dialog.findViewById(R.id.txt_update_phone);
                EditText edtadd = dialog.findViewById(R.id.txt_update_address);
                EditText edtpass = dialog.findViewById(R.id.txt_update_pass);
//                String roll;
                AppCompatButton btn_add_update = dialog.findViewById(R.id.btn_add_update);
                TextView textView = dialog.findViewById(R.id.update_title);

                textView.setText("Update Contact");
                btn_add_update.setText("Update");
//                roll = arrstudent.get(position).roll;
                edtname.setText(arrstudent.get(position).name);
                edtemail.setText(arrstudent.get(position).email);
                edtphone.setText(arrstudent.get(position).mobileno);
                edtadd.setText(arrstudent.get(position).address);
                edtpass.setText(arrstudent.get(position).password);

                btn_add_update.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String name = "", email = "", phone = "", add = "", pass = "",
                        rollno = arrstudent.get(position).roll;

                        if (!rollno.equals("") && !edtname.getText().toString().equals("") && !edtemail.getText().toString().equals("") && !edtphone.getText().toString().equals("") && !edtadd.getText().toString().equals("") && !edtpass.getText().toString().equals("")) {
                            rollno = arrstudent.get(position).roll;
                            name = edtname.getText().toString();
                            email = edtemail.getText().toString();
                            phone = edtphone.getText().toString();
                            add = edtadd.getText().toString();
                            pass = edtpass.getText().toString();
                            arrstudent.set(position, new StudentModel(rollno, name, email, phone, add, pass));

                            notifyItemChanged(position);

//                            Update Student database

                            StudentDBHelper studentDBHelper = new StudentDBHelper(context);
                            studentDBHelper.allDetailsUpdate(rollno, name, email, phone, add, pass);

                            dialog.dismiss();

                        } else {
                            Toast.makeText(holder.layout.getContext(), "All fields are required", Toast.LENGTH_SHORT).show();
                        }
//                        if (!edtname.getText().toString().equals("")) {
//                            name = edtname.getText().toString();
//                        } else {
//                            Toast.makeText(holder.layout.getContext(), "This field is required", Toast.LENGTH_SHORT).show();
//                        }
//
//                        if (!edtemail.getText().toString().equals("")) {
//
//                            email = edtemail.getText().toString();
//                        } else {
//                            Toast.makeText(holder.layout.getContext(), "This field is required", Toast.LENGTH_SHORT).show();
//                        }
//                        if (!edtphone.getText().toString().equals("")) {
//                            phone = edtphone.getText().toString();
//                        } else {
//                            Toast.makeText(holder.layout.getContext(), "This field is required", Toast.LENGTH_SHORT).show();
//                        }
//
//                        if (!edtadd.getText().toString().equals("")) {
//                            add = edtadd.getText().toString();
//                        } else {
//                            Toast.makeText(holder.layout.getContext(), "This field is required", Toast.LENGTH_SHORT).show();
//                        }
//
//                        if (!edtpass.getText().toString().equals("")) {
//                            pass = edtpass.getText().toString();
//                        } else {
//                            Toast.makeText(holder.layout.getContext(), "This field is required", Toast.LENGTH_SHORT).show();
//                        }
//                        if (!rollno.toString().equals("") && !edtname.getText().toString().equals("") && !edtemail.getText().toString().equals("") && !edtphone.getText().toString().equals("") && !edtadd.getText().toString().equals("") && !edtpass.getText().toString().equals("")) {
//
//                            arrstudent.set(position, new StudentModel(rollno, name, email, phone, add, pass));
//
//                            notifyItemChanged(position);
//
////                            Update Student database
//
//                            StudentDBHelper studentDBHelper = new StudentDBHelper(context);
//                            studentDBHelper.allDetailsUpdate(rollno, name, email, phone, add, pass);
//
//                            dialog.dismiss();
//                        } else {
//                            Toast.makeText(holder.layout.getContext(), "This field is required", Toast.LENGTH_SHORT).show();
//                        }
                    }
                });
                dialog.show();
            }
        });
        holder.layout.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context).setTitle("Delete Data").setMessage("Are you sure went to delete?").setIcon(R.drawable.baseline_delete_24).setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String rollno = arrstudent.get(position).roll;

                        arrstudent.remove(position);
                        notifyItemChanged(position);

//                                Delete data in Database
                        StudentDBHelper studentDBHelper = new StudentDBHelper(context);
                        studentDBHelper.deleteStudent(rollno);

                    }
                }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                builder.show();
                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return arrstudent.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder {
        TextView txtroll, txtname, txtemail, txtmobile, txtaddress, txtpassword;
        LinearLayout layout;

        public viewHolder(@NonNull View itemView) {
            super(itemView);
            txtroll = itemView.findViewById(R.id.txtroll);
            txtname = itemView.findViewById(R.id.txtname);
            txtemail = itemView.findViewById(R.id.txtemail);
            txtmobile = itemView.findViewById(R.id.txtphone);
            txtaddress = itemView.findViewById(R.id.txtaddress);
            txtpassword = itemView.findViewById(R.id.txtpassword);
            layout = itemView.findViewById(R.id.llrow);
        }

    }
}